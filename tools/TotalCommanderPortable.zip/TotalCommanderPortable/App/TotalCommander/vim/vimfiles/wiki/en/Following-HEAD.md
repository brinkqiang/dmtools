This page documents changes in master branch which may require users to update configuration.

### PreRelease

#### Changed

#### Added

#### Removed

### V0.6.0

SpaceVim releases v0.6.0 at 2017-12-30, please check the [release page](https://spacevim.org/SpaceVim-release-v0.6.0/) for all the details
