欢迎来到 <img src="https://spacevim.org/SpaceVim.png" height="17" width="17"> **SpaceVim** 维基, 一个关于 SpaceVim的资源导航!

- [简介](Introduction)  
- [特性](Features)

## 用户

- [用户文档](https://spacevim.org/documentation)
    - [快速入门](quick-start-guide)
- [获取帮助](getting-help)
- [安装](Installing-SpaceVim)
- [更新](Update)
- [社区](http://spacevim.org/community/)

## 开发者

这一wiki是通过 [`wiki/cn/`](https://github.com/SpaceVim/SpaceVim/tree/master/wiki/cn) 目录自动生成的, 如果你想更新wiki，可以像主仓库提交 PR。
