[![SpaceVim home](https://spacevim.org/logo.png)](Home)
--
[Introduction](introduction)  
[Community](community)  
[FAQ](FAQ)  
[Layers](https://spacevim.org/layers/)

**Users**  
[Install](Installing-SpaceVim)
[Following HEAD](Following-HEAD)
[Docs](http://spacevim.org/documentation/)

**Developers**  
[Contribute](https://spacevim.org/development/)  
[Tips & Tools](Development-tips)  
[Code style](http://spacevim.org/conventions/)  
