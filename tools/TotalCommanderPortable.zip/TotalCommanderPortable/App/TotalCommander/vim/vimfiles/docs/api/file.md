---
title: "file api"
---

# [APIs](https://spacevim.org/apis) : file

## values

name   | values | description
----- |:----:| ------------------
separator | `/` or `\` | The system-dependent name-separator character.
pathSeparator | `:` or `;` |  The system-dependent path-separator character.

## functions
