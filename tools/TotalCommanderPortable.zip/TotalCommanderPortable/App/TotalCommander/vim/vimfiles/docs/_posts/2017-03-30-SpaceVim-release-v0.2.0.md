---
title: SpaceVim release v0.2.0
categories: changelog
excerpt: "Mnemonic key bindings in SpaceVim"
type: NewsArticle
comments: true
---

# [Changelogs](https://spacevim.org/development#changelog) > SpaceVim release v0.2.0

SpaceVim is a community-driven vim distribution inspired by spacemacs. 

features:
**Mnemonic key bindings:** commands have mnemonic prefixes like <kbd>[Window]</kbd> for all the window and buffer commands or <kbd>[Unite]</kbd> for the unite work flow commands.

**Denite support:** <kbd>[Denite]</kbd> key guide for denite.
